

angular.module('app', ['ngRoute', 'ngSanitize'])

.config(function($routeProvider, $locationProvider) {
	$locationProvider.html5Mode(true);

	$routeProvider
	.when('/', {
		templateUrl: myLocalized.partials + 'main.html',
		controller: 'Main'
	})
	.when('/:ID', {
		templateUrl: myLocalized.partials + 'content.html',
		controller: 'Content'
	});
})
.controller('Main', function($scope, $http, $routeParams) {
	$http.get('http://localhost:8888/NK_Head/wp-json/wp/v2/posts/').success(function(res){
		$scope.posts = res;
	});
})
.controller('Content', function($scope, $http, $routeParams) {
	$http.get('http://localhost:8888/NK_Head/wp-json/wp/v2/posts/' + $routeParams.ID).success(function(res){
		$scope.post = res;
	});


});

var colors= ['#FF8647', '#F28E85', '#D85051'];
var i = 0;

setInterval(function(){ 

		/*$('.weeee').css('background-color:' + colors[i] + ';');*/
		

		if(i >= colors.length){

			i = 0;
		};

		$("body").css("background-color", colors[i]);
		

		i++;
		

}, 5000);


