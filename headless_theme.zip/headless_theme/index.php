<!DOCTYPE html>
<html ng-app = "app">
<head>
	<base href="/NK_Head/">
	<title>Headless WP Theme</title>

	<?php wp_head(); ?>
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/style.css"/>
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/reset.css"/>

</head>
<body>

	<header>
		<h1>
			<a href="<?php echo site_url(); ?>">Headless WP Theme</a>
		</h1>
	</header>

	
<div ng-view>
	

</div>

	<footer>
		&copy; <?php echo date( 'Y' ); ?> 
		<a href="<?php echo site_url(); ?>">AngularJS Demo Theme</a>
	</footer>


</body>


</html>